Font that was used for the background of the preview:
http://www.dafont.com/optimusprinceps.font
Texture that was used for the background of the icons and preview:
http://www.onlygfx.com/wp-content/uploads/2016/07/smooth-brown-leather-2.jpg